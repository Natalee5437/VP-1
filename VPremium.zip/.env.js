### Email (Gmail)
USER_EMAIL_PROVIDER = 'hagozox@gmail.com'
USER_NAME = 'hagozox'
USER_EMAIL = 'hagozox@gmail.com'
USER_APP_PASSWORD = 'ogrqrvuqqspskzpd'

### Neoxr API : https://api.neoxr.my.id
API_KEY = 'Aprilll'

### Open AI : https://beta.openai.com/account/api-keys
OPENAI_API_KEY = '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'

### Database : https://www.mongodb.com/
DATABASE_URL = 'mongodb+srv://hagozox:friBkCYQPdsRbPWK@cluster0.mxoimg2.mongodb.net/?retryWrites=true&w=majority'

### Chatbot (Auto Reply) : https://brainshop.ai/
BRAIN_API_ID = 172389
BRAIN_API_SECRET = 'ryw2Ek6jmPvDbgL6'

### Anti Porn : https://api.sightengine.com
API_USER = '1118099373'
API_SECRET = 'jA8RntKFhyPKMHMvhiu6'

### Audio Transcription (Whisper) : https://replicate.com/account/api-tokens
REPLICATE_API_TOKEN = 'r8_ME8LUthsHIvil99IOzHyzx4iEYx1tMF2L48Da'