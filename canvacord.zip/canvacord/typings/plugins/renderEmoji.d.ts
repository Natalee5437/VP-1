declare function _exports(ctx: any, message: any, x: any, y: any): Promise<any>;
export = _exports;
//# sourceMappingURL=renderEmoji.d.ts.map