declare function _exports(ctx: any, x: any, y: any, width: any, height: any, radius: any): any;
export = _exports;
//# sourceMappingURL=round.d.ts.map