declare function _exports(ctx: any, w: any, h: any): any;
export = _exports;
//# sourceMappingURL=circle.d.ts.map