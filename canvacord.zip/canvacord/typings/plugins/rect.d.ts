declare function _exports(ctx: any, x: any, y: any, height: any, width: any, color: any, stroke?: boolean, lineWidth?: number): any;
export = _exports;
//# sourceMappingURL=rect.d.ts.map