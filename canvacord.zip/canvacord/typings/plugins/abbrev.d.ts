declare function _exports(num: any): string;
export = _exports;
//# sourceMappingURL=abbrev.d.ts.map