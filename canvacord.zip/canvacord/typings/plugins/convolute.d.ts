declare function _exports(ctx: any, canvas: any, matrix: any, opaque: any): any;
export = _exports;
//# sourceMappingURL=convolute.d.ts.map