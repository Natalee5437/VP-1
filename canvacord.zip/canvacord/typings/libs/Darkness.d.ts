declare function _exports(img: any, amount: any): Promise<Buffer>;
export = _exports;
//# sourceMappingURL=Darkness.d.ts.map