declare function _exports(img: any): Promise<Buffer>;
export = _exports;
//# sourceMappingURL=Invert.d.ts.map