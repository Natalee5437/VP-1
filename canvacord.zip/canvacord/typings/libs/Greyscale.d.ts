declare function _exports(img: any): Promise<Buffer>;
export = _exports;
//# sourceMappingURL=Greyscale.d.ts.map