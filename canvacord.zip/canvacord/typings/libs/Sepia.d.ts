declare function _exports(img: any): Promise<Buffer>;
export = _exports;
//# sourceMappingURL=Sepia.d.ts.map