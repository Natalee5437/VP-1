declare function _exports(image: any, TRIGGERED: any): Promise<any>;
export = _exports;
//# sourceMappingURL=Trigger.d.ts.map