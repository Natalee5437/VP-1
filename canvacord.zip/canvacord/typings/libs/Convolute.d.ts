declare function _exports(img: any, matrix: any, opaque: any, lvl: any): Promise<Buffer>;
export = _exports;
//# sourceMappingURL=Convolute.d.ts.map