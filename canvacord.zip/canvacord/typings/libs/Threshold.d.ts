declare function _exports(img: any, amount?: number): Promise<Buffer>;
export = _exports;
//# sourceMappingURL=Threshold.d.ts.map