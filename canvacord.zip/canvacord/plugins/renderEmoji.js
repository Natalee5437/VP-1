module.exports = async (ctx, message, x, y) => {
    return ctx.fillText(message, x, y);
};